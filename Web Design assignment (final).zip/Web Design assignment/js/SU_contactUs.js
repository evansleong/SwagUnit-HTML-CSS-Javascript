document.forms[0].onsubmit = function () {
    alert("Successfully submitted, Thank you !");
    alert(Date());
  }

  