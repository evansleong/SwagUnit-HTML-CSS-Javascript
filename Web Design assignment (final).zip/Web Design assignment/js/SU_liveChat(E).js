const responseObj = {
    Hello: "Hello,What can we help you ?",
    Hi: "Hi,What can we help you ?",
    Hey: "Hey,What can we help you ?",
    Thanks: "Welcome,have a nice day !",
    hello: "Hello,What can we help you ?",
    hi: "Hi,What can we help you ?",
    hey: "Hey,What can we help you ?",
    thanks: "Welcome,have a nice day !",
    Bye: "Bye bye !",
    bye: "Bye bye !"
    
};
