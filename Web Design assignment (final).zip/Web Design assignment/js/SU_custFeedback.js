function validateForm() {
  alert("Successfully submitted, Thank you !");
  alert(Date());
}